library(shiny)
library(tidyr)
library(leaflet)
library(shinyWidgets)
library(DT)
library(RColorBrewer)
library(scales)
library(lattice)
library(dplyr)

#import here any other packages you'll need
#install.packages(C("leaflet", "RColorBrewer","scales", "lattice", "dplyr"))
#install.packages("leaflet")
#install.packages( "RColorBrewer") 
#install.packages("scales") 
#install.packages("lattice") 
#install.packages("dplyr")
#install.packages("shinyWidgets")
######################################################
# Loads the csv file into a dataframe
my_data <- read.csv("./data/CrimesDS.csv",header=TRUE, sep=",")
df2 <- read.csv("./data/PFCrimes1.csv")

#Clean duplicates
df<- unique(my_data)

#Split Time e Date and define data types
df$Date <- as.Date(df$Date,format="%m/%d/%Y")
df$Time <- as.POSIXct(df$Time,format="%H:%:M%:S")
df$Year <- as.numeric(df$Year)
df$Month <- as.numeric(df$Month)
df$Day <- as.numeric(df$Day)
df$Category <- as.character (df$Category)
df$DayOfWeek <- as.character(df$DayOfWeek)
df$Address <- as.character(df$Address)
df$PdDistrict <- as.character(df$PdDistrict)
df$Resolution <- as.factor(df$Resolution)
df$Descript <- as.character (df$Descript)


#Data Explore dataframe
df3 <- data.frame("Date"= as.Date(df$Date,format="%m/%d/%Y"),
                  "Time" = as.Date(df$Date,format="%H:%:M%:S"),
                  "District" = as.character(df$PdDistrict), 
                  "Address" = as.character(df$Address), 
                  "Category" = as.character(df$Category), 
                  "Resolution" = as.character(df$Resolution))

###UI#################################################

ui <-  navbarPage(title = "Crimes of San Francisco",
           
    tabPanel("Interactive Map",
             sidebarLayout(sidebarPanel(width = 2,
               dateInput("map_date","Select a date.", min = min(df$Date), max = max(df$Date),format = "yyyy-mm-dd", startview = "decade"),
               selectInput(inputId = "map_crime", label = "Select a crime category.", choices = c("ALL", sort(unique(df$Category))), multiple=TRUE),
               actionButton("update", "Update Map")
             ),
            mainPanel(leafletOutput("sfmap", width="100%", height = 1200)))
            ),
    
    tabPanel("Data Explorer",             
               fluidRow( column(3,
                 selectInput("districts", "District:", choices = c("ALL DISTRICTS"="", sort(unique(df$PdDistrict))), multiple=TRUE),
                 #conditionalPanel("input_districts",
                 selectInput("addresses", "Address:", choices = c("ALL ADRESSES"=""), multiple=TRUE),
                 #conditionalPanel("input_districts",
                 selectInput("crimes", "Crime type:", choices = c("ALL CATEGORIES"=""), multiple=TRUE),
                dateRangeInput("table_date","Date range:", start = min(df$Date), end = max(df$Date), min = min(df$Date), max = max(df$Date),format = "yyyy-mm-dd", startview = "decade"),
                textOutput("table_date_text")),
                column(8, DT::dataTableOutput("table"))
             
    )))
             
###SERVER########################################

server <- function(input, output, session) {
  
###Interactive Map###############################  
  output$sfmap <- renderLeaflet({
    leaflet() %>% 
      addTiles() %>% 
      setView(lng = -122.4167, lat = 37.7834,zoom = 15)
    
    filter_mapdata <- reactive({ df[df$Category == input$map_crime,
                                    df$Date == input$map_date]})
    
    observe( leafletProxy("sfmap", data = filter_mapdata()) %>%
               clearMarkers()%>%
               addMarkers(lng = df$X, lat = df$Y, popup = df$Category)
    )
      
  })
  
###Data Explorer################################# 

  output$table_date_text <- renderText({
    validate(need(input$table_date[2] > input$table_date[1], "Invalid date range! End date is earlier than start date."))})
  
  #Filter data accordingly the district selected. The Address selection is updated keeping only the addresses inside that district(still_select var).              
  observe({
    addresses <- if (is.null(input$districts)) character(0) else {
      filter(df3, District %in% input$districts) %>%
        `$`('Address') %>%
        unique() %>%
        sort()
    }
    stillSelected <- isolate(input$addresses[input$addresses %in% addresses])
    updateSelectInput(session, "addresses", choices = c("ALL ADDRESSES"= "", sort(unique(addresses))), selected = stillSelected)
  })
  
  #Filter data accordingly the district selected and (if selected) the adress. The Category selection is updated keeping only the crimes that happened inside the location selected.
  observe({
    crimes <- if (is.null(input$districts)) character(0) else {
      df3 %>%
        filter(District %in% input$districts,
               is.null(input$addresses) | Address %in% input$addresses) %>%
        `$`('Category') %>%
        unique() %>%
        sort()
    }
    stillSelected <- isolate(input$crimes[input$crimes %in% crimes])
    updateSelectInput(session, "crimes", choices = c("ALL CATEGORIES"= "", sort(unique(crimes))), selected = stillSelected)
  })
  
  
  #Create the table with the data previously filtered.
  output$table <- DT::renderDataTable({
    filtered_df3 <- df3 %>%
      filter(
        Date <= input$table_date[2],
        Date >= input$table_date[1],
        is.null(input$districts) | District %in% input$districts,
        is.null(input$addresses) | Address %in% input$addresses,
        is.null(input$crimes) | Category %in% input$crimes
      )
    DT::datatable( filtered_df3, options = list( lengthMenu = c(15, 25, 50), pageLength = 20))
  })
}

##################################################
shinyApp(ui = ui, server = server)