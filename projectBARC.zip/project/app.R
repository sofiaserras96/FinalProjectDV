require(shiny)
require(highcharter)

df<- read.csv('data/PFCrimes1.csv')
df1<- read.csv('data/PFCrimes.csv')

df$frequency <- df$frequency * 100
df$acc_frequency <- df$acc_frequency * 100

ui <- fluidPage(
  titlePanel('FinalProject'),
  tabsetPanel(
    tabPanel('Bar chart', highchartOutput('plot1')),
      ),
  ) 

server <- function(input, output) {
  
  
  treemap.data <- reactive({
    ix <- which(df$location == input$location)
    tmp <- t(df[ix, c("ARSON","ASSAULT","BAD CHECKS","BRIBERY","BURGLARY","DISORDERLY CONDUCT","DRUG/NARCOTIC","DRUNKENNESS","EMBEZZLEMENT","EXTORTION","FAMILY OFFENSES","FORGERY/COUNTERFEITING","FRAUD","GAMBLING","KIDNAPPING","LARCENY/THEFT","LIQUOR LAWS","LOITERING,MISSING PERSON","NON-CRIMINAL","OTHER OFFENSES","PROSTITUTION","ROBBERY","RUNAWAY","SECONDARY CODES","SEX OFFENSES FORCIBLE","SEX OFFENSES NON FORCIBLE","STOLEN PROPERTY","SUICIDE","SUSPICIOUS OCC","TREA","TRESPASS","VANDALISM","VEHICLE THEFT","WARRANTS","WEAPON LAWS")])
    location.count <- as.vector(tmp)
    tmp.df1 <- data.frame("location"=c("ARSON","ASSAULT","BAD CHECKS","BRIBERY","BURGLARY","DISORDERLY CONDUCT","DRUG/NARCOTIC","DRUNKENNESS","EMBEZZLEMENT","EXTORTION","FAMILY OFFENSES","FORGERY/COUNTERFEITING","FRAUD","GAMBLING","KIDNAPPING","LARCENY/THEFT","LIQUOR LAWS","LOITERING,MISSING PERSON","NON-CRIMINAL","OTHER OFFENSES","PROSTITUTION","ROBBERY","RUNAWAY","SECONDARY CODES","SEX OFFENSES FORCIBLE","SEX OFFENSES NON FORCIBLE","STOLEN PROPERTY","SUICIDE","SUSPICIOUS OCC","TREA","TRESPASS","VANDALISM","VEHICLE THEFT","WARRANTS","WEAPON LAWS"), "count"=location.count*100)
    tmp.df1
  })
  
  # Bar chart
  output$plot1 <- renderHighchart({
    
    x <- c("ARSON","ASSAULT","BAD CHECKS","BRIBERY","BURGLARY","DISORDERLY CONDUCT","DRUG/NARCOTIC","DRUNKENNESS","EMBEZZLEMENT","EXTORTION","FAMILY OFFENSES","FORGERY/COUNTERFEITING","FRAUD","GAMBLING","KIDNAPPING","LARCENY/THEFT","LIQUOR LAWS","LOITERING,MISSING PERSON","NON-CRIMINAL","OTHER OFFENSES","PROSTITUTION","ROBBERY","RUNAWAY","SECONDARY CODES","SEX OFFENSES FORCIBLE","SEX OFFENSES NON FORCIBLE","STOLEN PROPERTY","SUICIDE","SUSPICIOUS OCC","TREA","TRESPASS","VANDALISM","VEHICLE THEFT","WARRANTS","WEAPON LAWS", "Acc. frequency")
    
    y <- sprintf("{point.%s}: .2f", 
                 c("ARSON","ASSAULT","BAD CHECKS","BRIBERY","BURGLARY","DISORDERLY CONDUCT","DRUG/NARCOTIC","DRUNKENNESS","EMBEZZLEMENT","EXTORTION","FAMILY OFFENSES","FORGERY/COUNTERFEITING","FRAUD","GAMBLING","KIDNAPPING","LARCENY/THEFT","LIQUOR LAWS","LOITERING,MISSING PERSON","NON-CRIMINAL","OTHER OFFENSES","PROSTITUTION","ROBBERY","RUNAWAY","SECONDARY CODES","SEX OFFENSES FORCIBLE","SEX OFFENSES NON FORCIBLE","STOLEN PROPERTY","SUICIDE","SUSPICIOUS OCC","TREA","TRESPASS","VANDALISM","VEHICLE THEFT","WARRANTS","WEAPON LAWS", "acc_frequency"))
    
    tltip.str <- "<strong><i>{point.location}</i></strong><br>
                  <strong style=\"color:#FF6600;\">ARSON</strong>: {point.ARSON}<br>
                  <strong style=\"color:#FF6600;\">ASSAULT</strong>: {point.ASSAULT}<br>
                  <strong style=\"color:#FF6600;\">BAD CHECKS</strong>: {point.BAD CHECKS}<br>
                  <strong style=\"color:#FF6600;\">BRIBERY</strong>: {point.BRIBERY}<br>
                  <strong style=\"color:#FF6600;\">BURGLARY</strong>: {point.ARSON}<br>
                  <strong style=\"color:#FF6600;\">DISORDERLY CONDUCT</strong>: {point.DISORDERLY CONDUCT}<br>
                  <strong style=\"color:#00FFFF;\">
                    capital</strong>: "
  
    
    max_freq <- max(df$frequency)
    

    highchart() %>%
      hc_add_series(df, "column", 
                    hcaes(y = frequency), name = 'Percentage of records') %>%
      hc_yAxis(
        title = list(text = 'Percentage of records'),
        labels = list(format = '{value}%'),
        max = max_freq
      ) %>%
      hc_xAxis(categories = df$location) %>%
      hc_tooltip(useHTML = TRUE, headerFormat = '', pointFormat = tltip.str)
    
  })
  output$plot2 <- renderHighchart({
    
    tlp.str <- "<i>{point.count: %.1f}</i>"
    
    # here we'll be creating the treemap chart
    treemap.data() %>%
      # this is highchar aesthetics: this is how we bind data with visual elements
      # like color, shape, etc
      hchart("treemap", hcaes(x=location, value=count, color=count)) %>%
      hc_title(text="AAAAAAAAAAAA", style=list(fontsize="16px")) %>%
      hc_tooltip(pointFormat=tlp.str) %>%
      hc_add_theme(hc_theme_economist())
    
  })

  
}
shinyApp(ui, server)
